from django.db import models
"""
class storedata_D(models.Model):
    name=models.TextField()
    data=models.ImageField(upload_to ="new/")
    class Meta:
        db_table="storedata"
"""
class finalp(models.Model):
    name=models.TextField()
    data=models.ImageField(upload_to ="img/")