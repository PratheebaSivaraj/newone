from django.contrib import admin
from .models import finalp
admin.site.register(finalp)
# Register your models here.
